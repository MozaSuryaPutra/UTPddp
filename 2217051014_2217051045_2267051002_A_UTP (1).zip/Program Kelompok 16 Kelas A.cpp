#include <iostream>
using namespace std;
void foto(){
	
		int n = 1; 
		int nomor;
		int counter = 0;
        int harga[4];
	string alamat;
	string nomorhp;
	string nama;
	char ulangi = 'y';
	
harga[0]=150000;
harga[1]=400000;
harga[2]=50000;
harga[3]=100000;

	int jumlah,total;
	char pilihan;
	cout<<"==========================================================================="<<endl;
	cout<<"       Masukan Data Diri Anda Sebagai Pelanggan Terbaik Toko Kami         |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"Nama      : ";
	getline(cin,nama);
	cout<<"Asal Kota : ";
	getline(cin,alamat);
	cout<<"Nomor Hp  : ";
	cin>>nomorhp;
	system("color a");
	do{
			cout<<"***************************************************************************"<<endl;
	cout<<"*			   DAFTAR HARGA PHOTOCARD JKT48                   *"<<endl;
	cout<<"***************************************************************************"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[No] 	 NAME MEMBER       |                    HARGA                     |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[1.] Photocard Shani       | 			150000              	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[2.] Photocard Feni        | 			400000              	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[3.] Photocard Chika       | 			50000               	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[4.] Photocard Freya       | 			100000              	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[5.] Riwayat Pembelian                                                	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[6.] Biodata diri pelanggan                                               |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<"[7.] Keluar Dari Toko                                                 	  |"<<endl;
	cout<<"==========================================================================="<<endl;
	cout<<endl;
	cout<<"Pilihan kakak : ";
	cin>>pilihan;

	if(pilihan == '1'){
		nomor=1;
		cout<<"Masukkan Jumlah : ";
	   		cin>>jumlah;
			total=harga[0]*jumlah;
				n = n + 1; 
				cout<<"Pembayaran anda adalah "<<total<<" Rupiah"<<endl;
}
	else if(pilihan=='2'){
		nomor=2;
		cout<<"Masukkan Jumlah : ";
			cin>>jumlah;
			total=harga[1]*jumlah;
				n = n + 1; 
				cout<<"Pembayaran anda adalah "<<total<<" Rupiah"<<endl;
}
	else if(pilihan=='3'){
		nomor=3;
		cout<<"Masukkan Jumlah : ";
			cin>>jumlah;
			total=harga[2]*jumlah;
				n = n + 1; 
				cout<<"Pembayaran anda adalah "<<total<<" Rupiah"<<endl;
}
   else if(pilihan == '4'){
   	nomor=4;
   	cout<<"Masukkan Jumlah : ";
			cin>>jumlah;
			total=harga[3]*jumlah;
				n = n + 1; 
				cout<<"Pembayaran anda adalah "<<total<<" Rupiah"<<endl;
}
    else if (pilihan=='5') 
	   { 
	   system("color b");
	    	cout<<"-=-=-=-=-=-=-=-[Daftar Nama Photocard dalam Kresek Belanja]-=-=-=-=-=-=-=-="<<endl;
		if (n < 2) {
			cout<<".......Photocard yang anda beli Kosong kaya hati lo......."<<endl;
		}else  {
			for (int j=1; j<n; j++ ) 
			{
			cout<<"[Kresek ke "<<j<<"]"<<"								|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Nomor pilihan] : "<<nomor<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Jumlah photocard] : "<<jumlah<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Total Harga] : "<<total<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			}
	}
		}	else if(pilihan =='6'){
		cout<<"Nama      : "<<nama<<endl;
			cout<<"Asal Kota : "<<alamat<<endl;
			cout<<"Nomor Hp  : "<<nomorhp<<endl;
	
		}else if(pilihan =='7'){
			 {
			cout<<"-=-=-=-=-=-=-=-=-[Daftar Nama Photocard dalam Kresek Belanja]-=-=-=-=-=-=-="<<endl;
		if (n < 2) {
			cout<<".......Photocard yang anda beli Kosong kaya hati lo......."<<endl;
		}
		else {
			for (int j=1; j<n; j++ ) 
			{
			cout<<"[Kresek ke "<<j<<"]"<<"								|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Nomor pilihan] : "<<nomor<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Jumlah photocard] : "<<jumlah<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Total Harga] : "<<total<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			}
		}
		
			cout<<"....Terimakasih Sudah Mengunjungi Toko Kami, Silahkan bayar kak....";
				exit (0);}
}else {
	cout<<"Tidak ada Pilihan";
	exit(0);
}
	
			cout<<"Apakah kakak mau melanjutkan lagi? (y/t) : ";
				cin>>ulangi;
				counter++;
	system("cls");

}while(ulangi=='y' || ulangi=='Y');
for (int j=1; j<n; j++ ) 
			{
			cout<<"[Kresek ke "<<j<<"]"<<"								|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Nomor pilihan] : "<<nomor<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Jumlah photocard] : "<<jumlah<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"[Total Harga] : "<<total<<"							|"<<endl;
			cout<<"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"<<endl;
			cout<<"Jangan lupa bayar bro....."<<endl;
			}
cout<<endl;
}


int main(){
	system("color c");
			cout<<"|=================================================================================================================|\n"; 
			cout<<"|========================================|SELAMAT DATANG DI TOKO PHOTOCARD JKT48 |================================|\n";
			cout<<"|=================================================================================================================|"<<endl<<endl;	
	foto();
	     	cout<<"[Terimakasih Sudah Berkunjung Di Toko Kami]"<<endl;           
}
